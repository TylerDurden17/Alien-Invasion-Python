import sys
import pygame
from bullet import Bullet
from bullet1 import Bullet2
def check_keydown_events(event, ai_settings, screen, ship, bullets):
			"""respond to keypresses"""
			if event.key == pygame.K_UP:
				ship.moving_up = True
			elif event.key == pygame.K_DOWN:
				ship.moving_down = True
			elif event.key == pygame.K_SPACE:
				#create new bullet and add it to the bullets group
				new_bullet = Bullet(ai_settings, screen, ship)
				bullets.add(new_bullet)
				new_bullet2 = Bullet2(ai_settings, screen, ship)
				bullets.add(new_bullet2)
		
def check_keyup_events(event, ship):
			"""respond to key releases"""
			if event.key == pygame.K_UP:
				ship.moving_up = False
			elif event.key == pygame.K_DOWN:
				ship.moving_down = False

def check_events(ai_settings, screen, ship, bullets):
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			sys.exit()
		elif event.type == pygame.KEYDOWN:
			check_keydown_events(event, ai_settings, screen, ship, bullets)
		elif event.type == pygame.KEYUP:
			check_keyup_events(event, ship)

				
def update_screen(ai_settings, screen, ship, bullets):
	#update images on the screen and flip to the new screen.
	screen.fill(ai_settings.bg_color)
	#redraw all bulletsbehind ship and aliens.
	for bullet in bullets.sprites():
		bullet.draw_bullet()
	ship.blitme()

	pygame.display.flip()
