import pygame

class Ship():

	def __init__(self, ai_settings, screen):
		self.screen = screen
		self.ai_settings = ai_settings
		# load the ship and get its rect.
		self.image = pygame.image.load('images/ship2.bmp')
		self.rect = self.image.get_rect()
		self.screen_rect = screen.get_rect()

		#bottom center
		self.rect.centery = self.screen_rect.centery
		self.rect.left = self.screen_rect.left

		#decimal value
		self.center = float(self.rect.centery)

		#movement flags
		self.moving_up = False
		self.moving_down = False


	def update(self):
		if self.moving_up and self.rect.top >= 0:
			self.center -= self.ai_settings.ship_speed_factor
		if self.moving_down and self.rect.bottom < self.screen_rect.bottom:# and self.rect.top < self.screen_rect.top:
			self.center += self.ai_settings.ship_speed_factor
		#if self.moving_down and self.rect.down > 0:
		#	self.center -= self.ai_settings.ship_speed_factor

		#update rect object from self center.
		self.rect.centery = self.center

	def blitme(self):
		"""draw the ship"""
		self.screen.blit(self.image, self.rect)